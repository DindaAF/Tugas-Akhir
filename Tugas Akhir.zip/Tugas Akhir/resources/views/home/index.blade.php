@extends('layouts.master')
@section('content')
<div class="main">
	<div class="main-content">
		<div class="container-fluid">			
			@if (Session::has('success'))
			<div class="alert alert-success">
				{{ Session::get('success') }}
			</div>
			@endif
			@if (Session::has('success2'))
			<div class="alert alert-success">
				{{ Session::get('success2') }}
			</div>
			@endif
			<div class="panel panel-profile" style="height: 1000px;">
						<div class="clearfix">
							<!-- LEFT COLUMN -->
							<div class="profile-left">
								<!-- PROFILE HEADER -->
								<div class="profile-header">
									<div class="overlay"></div>
									<div class="profile-main">
										<a href="{{Auth::user()->getPhotoProfil()}}"><img src="{{Auth::user()->getPhotoProfil()}}" class="img-circle" alt="Avatar" style="border: 1px solid #000000; width: 80px;height: 80px; overflow: hidden; border-radius: 50%;"></a>
										<h3 class="name">{{ Auth::user()->name}}({{Auth::user()->role}})</h3>
										<span>{{Auth::user()->username}}</span>
									</div>
								</div>
								<!-- END PROFILE HEADER -->
								<!-- PROFILE DETAIL -->
								<div class="profile-detail">
									<div class="profile-info">
										<ul class="list-unstyled activity-timeline">
											@foreach($data_works as $works)
											@if($works->users->id == Auth::user()->id)
											<li>
												<i class="lnr lnr-briefcase activity-icon"></i>
												<p><b style="font-size: 20px;">Perusahaan : {{$works->company}}</b>
													<span class="timestamp"><b>Alamat Perusahaan : </b>{{$works->works_place}}</span>
													<span class="title"><b>Posisi : </b>{{$works->position}}</span><br>
													<span class="short-description"><b>Deskripsi : </b>{{$works->description}}</span><br>
													<span class="date"><b>Tanggal Masuk : </b>{{date('d F Y', strtotime($works->date_start))}}</span><br>
													@if ($works->date_end == NULL)
													<span class="date" ><b>Tanggal Keluar : </b>Masih Bekerja</span><br>
													@else
													<span class="date" ><b>Tanggal Keluar : </b>{{date('d F Y', strtotime($works->date_end))}}</span><br>
													@endif
												</p>
											</li>
											@endif
											@endforeach
										</ul>
									</div>
								</div>
								<!-- END PROFILE DETAIL -->
							</div>
							<!-- END LEFT COLUMN -->
							<!-- RIGHT COLUMN -->
							<div class="profile-right">
								<div class="tab-content">
									<div id="tab-bottom-left1">
										<h4><strong>Data Diri</strong>
										<a href="/home/{{ Auth::user()->id}}/edit"><i class="fa fa-cog" style="color: #97cf16"></i></a></h4>
										<ul class="list-unstyled list-justify">
											<li><i class="fa fa-graduation-cap fa-fw w3-margin-right w3-large w3-text-teal" name="generation"></i> {{Auth::user()->generation}}</li>
											<li>
												@if(Auth::user()->gender == 'P')
												<i class="fa fa-female fa-fw w3-margin-right w3-large w3-text-teal" name="gender"></i>
												@else
												<i class="fa fa-male fa-fw w3-margin-right w3-large w3-text-teal" name="gender"></i> 
												@endif
											</li>
											<li>
												<i class="fa fa-calendar fa-fw w3-margin-right w3-large w3-text-teal" name="birthdate"></i> 
												{{date('d F Y', strtotime(Auth::user()->birthdate))}}
											</li>
											<li>
												<i class="fa fa-phone fa-fw w3-margin-right w3-large w3-text-teal" name="phone_number"></i> {{Auth::user()->phone_number}}</li>
											<li>
												<i class="fa fa-envelope fa-fw w3-margin-right w3-large w3-text-teal" name="email"></i> {{Auth::user()->email}}</li>
												<li>
												<i class="fa fa-home fa-fw w3-margin-right w3-large w3-text-teal" name="address"></i> 
												{{Auth::user()->address}}
											</li>
										</ul>
									</div>
									<br>
									<div>
										<h4>
											<i class="fa fa-book fa-fw w3-margin-right w3-text-teal" name="self_description"></i><strong>Tentang Saya</strong></h4>
										<p>{{Auth::user()->self_description}}</p>
									</div>
									</div>
								</div>
								<!-- END TABBED CONTENT -->
							</div>
							<!-- END RIGHT COLUMN -->
						</div>
					</div>
		</div>
	</div>
</div>
@endsection