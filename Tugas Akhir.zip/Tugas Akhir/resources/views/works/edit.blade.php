@extends('layouts.master')
@section('content')
@if(session('sukses'))
<div class="alert alert-success" role="alert">
	{{session('sukses')}}
</div>
@endif
<div class="main">
		<div class="main-content">
			<div class="container-fluid">
				<div class="panel panel-headline" style="background-color: #e6e6e6;">
						<div class="panel-heading">
							<h1 class="panel-title" style="margin-top: 10px; font-size: 40px;"><b>Ubah Pekerjaan</b></h1>
						</div>
						<div class="panel-body" style="margin-left: 15px;">
							<div class="row">
								<form action="/works/{{$works->id}}/update" method="POST" enctype="multipart/form-data">
									@csrf
									<input type="hidden" name="users_id" value="{{Auth::id()}}">
									<input type="hidden" name="id" value="{{$works->id}}">
									<div class="form-group @error('company') has-error @enderror">
										<label for="update_company">Perusahaan</label>
										<input name="company" type="text" class="form-control" id="update_company" placeholder="Perusahaan" value="{{$works->company}}">
										@error('company')
											<span class="text-danger" id="error">{{ $message }}</span>
										@enderror
									</div>
									<div class="form-group @error('position') has-error @enderror">
										<label for="update_position">Posisi</label>
										<input name="position" type="text" class="form-control" id="update_position" placeholder="Posisi" value="{{$works->position}}">
										@error('position')
										<span class="text-danger" id="error">{{ $message }}</span>
										@enderror
									</div>
									<div class="form-group @error('works_place') has-error @enderror">
										<label for="update_works_place">Alamat Perusahaan</label>
										<textarea name="works_place" class="form-control" id="update_works_place" rows="3" placeholder="Alamat Perusahaan">{{$works->works_place}}</textarea>
										@error('works_place')
										<span class="text-danger" id="error">{{ $message }}</span>
										@enderror
									</div>
									<div class="form-group @error('description') has-error @enderror">
										<label for="update_description">Deskripsi Pekerjaan</label>
										<textarea name="description" class="form-control" id="update_description" rows="3" placeholder="Deskripsi Pekerjaan">{{$works->description}}</textarea>
										@error('description')
										<span class="text-danger" id="error">{{ $message }}</span>
										@enderror
									</div>
									<div class="form-group">
										<!-- Date input -->
										<label><strong>Tanggal Masuk</strong></label>
										<input class="form-control" id="date" name="date_start" placeholder="MM/DD/YYY" type="date" value="{{$works->date_start}}" required/>
										@error('date_start')
										<div class="alert alert-danger">*Tanggal Masuk Pekerjaan harap diisi</div>
										@enderror
									</div>
									<div class="form-group">
										<!-- Date input -->
										<label><strong>Tanggal Keluar</strong></label>
										<input class="form-control" id="date" name="date_end" placeholder="MM/DD/YYY" type="date" value="{{$works->date_end}}"/>
										
									</div>
									<div class="form-group">
										<!-- Date input -->
										<label><strong>Sampai saat ini</strong></label>
										<input class="form-check-label" type="checkbox" value="{{$works->date_end}} <?php if ($works->date_end == NULL) {
												echo 'Masih bekerja';
											}; ?>
											<?php  ?>" />
										
									</div>
									<button type="submit" class="btn btn-warning">Ubah</button>
								</form>
							</div>
						</div>
					</div>
			</div>
		</div>
</div>
@endsection
@section('my-script')
<script>
    @error('company')
        $('#error')
    @enderror
	@error('position')
        $('#error')
    @enderror
	@error('works_place')
        $('#error')
    @enderror
	@error('description')
        $('#error')
    @enderror
</script>
@endsection