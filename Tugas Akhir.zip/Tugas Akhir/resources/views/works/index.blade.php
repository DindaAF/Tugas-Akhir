@extends('layouts.master')
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.3/css/jquery.dataTables.css">
@section('content')
<div class="main">
	<div class="main-content">
		<div class="container-fluid">
			@if (Session::has('sukses1'))
			<div class="alert alert-success">
				{{ Session::get('sukses1') }}
			</div>
			@endif
			@if (Session::has('sukses3'))
			<div class="alert alert-danger">
				{{ Session::get('sukses3') }}
			</div>
			@endif
			@if (Session::has('sukses2'))
			<div class="alert alert-warning">
				{{ Session::get('sukses2') }}
			</div>
			@endif
			<div class="row">
				<div class="col-md-12">
					<div class="panel">
						<div class="col-md-4">
							<h1 style="text-align: left; margin-left: 10px;">Data Pekerjaan</h1>
						</div>
						<div class="col-md-8" style="text-align: right; margin-top: 20px;">
							<button type="button" class="btn btn-success" data-toggle="modal" data-target="#addModal" >Tambah Data</button>
							&nbsp;
							@if(Auth::user()->role == 'Admin')
							<button type="button" class="btn btn-primary"><a href="/works/export" style="margin-bottom: 10px; color: white;"> Export Excel</a></button>
							<button type="button" class="btn btn-primary"><a href="/works/exportpdf" style="margin-bottom: 10px; color: white;"> Export PDF</a></button>
							@endif
						</div>
						<div class="panel-body">
							<table id="works-index" class="table table-bordered table-hover table-striped">
								<thead>
									<tr>
										<th scope="col">Perusahaan</th>
										<th scope="col">Posisi</th>
										<th scope="col">Alamat</th>
										<th scope="col">Deskripsi</th>
										<th scope="col">Tanggal Masuk</th>
										<th scope="col">Tanggal Keluar</th>
										<th scope="col">Pengunggah</th>
										<th scope="col">Aksi</th>
									</tr>
								</thead>
								<tbody>
									@foreach($data_works as $works)
									<tr>
										<td scope="row">{{$works->company}}</td>
										<td>{{$works->position}}</td>
										<td>{{$works->works_place}}</td>
										<td>{{$works->description}}</td>
										<td>{{date('d F Y', strtotime($works->date_start))}}</td>
										<td>@if ($works->date_end == NULL)
												"Masih bekerja"
											@else
											{{date('d F Y', strtotime($works->date_end))}}
										@endif
										</td>
										<td>{{$works->users->name}}</td>
										<td align="center">
											<a href="/works/{{$works->id}}/edit" class="btn btn-warning btn-sm"><i class="fa fa-edit"></i></a>
											<a href="/works/{{$works->id}}/delete" class="btn btn-danger btn-sm" onclick="return confirm('Yakin data mau dihapus ?')"><i class="fa fa-trash"></i></a>
										</td>
									</tr>
									@endforeach
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<!-- Modal -->
<div class="modal fade" id="addModal" tabindex="-1" role="dialog" aria-labelledby="addModalLabel" aria-hidden="true">
	<div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
		<div class="modal-content">
			<div class="modal-header">
				<h1 class="modal-title" id="addModalLabel"><b>Tambah Pekerjaan</b></h1>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<form action="/works/create" method="POST" enctype="multipart/form-data">
				{{csrf_field()}}
				<input type="hidden" name="users_id" value="{{Auth::id()}}">
				<div class="modal-body" style="height: 70vh;overflow-y: auto;">
					<div class="form-group @error('company') has-error @enderror">
						<label for="input_company">Perusahaan</label>
						<input name="company" type="text" class="form-control" id="input_company" placeholder="Perusahaan">
					@error('company')
                        <span class="text-danger">{{ $message }}</span>
                    @enderror
					</div>
					<div class="form-group @error('position') has-error @enderror">
						<label for="input_position">Posisi</label>
						<input name="position" type="text" class="form-control" id="input_position" placeholder="Posisi">
						@error('position')
                        <span class="text-danger">{{ $message }}</span>
						@enderror
					</div>
					<div class="form-group @error('works_place') has-error @enderror">
						<label for="input_works_place">Alamat Perusahaan</label>
						<textarea name="works_place" class="form-control" id="input_works_place" rows="3" placeholder="Alamat Perusahaan"></textarea>
						@error('works_place')
                        <span class="text-danger">{{ $message }}</span>
						@enderror
					</div>
					<div class="form-group @error('description') has-error @enderror">
						<label for="input_description">Deskripsi Pekerjaan</label>
						<textarea name="description" class="form-control" id="input_description" rows="3" placeholder="Deskripsi Pekerjaan"></textarea>
						@error('description')
                        <span class="text-danger">{{ $message }}</span>
						@enderror
					</div>
					<div class="form-group">
						<!-- Date input -->
						<label><strong>Tanggal Masuk</strong></label>
						<input class="form-control" id="date" name="date_start" placeholder="MM/DD/YYY" type="date" required />
					</div>
					<div class="form-group">
						<!-- Date input -->
						<label><strong>Tanggal Keluar</strong></label>
						<input class="form-control" id="date" name="date_end" placeholder="MM/DD/YYY" type="date" />
					</div>
					<div class="form-group">
						<input class="form-check-label" type="checkbox" />
						<label><strong>Sampai saat ini</strong></label>
					</div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
					<button type="submit" class="btn btn-primary">Tambah</button>
				</div>
			</form>
		</div>
	</div>
</div>
<!-- End Modal -->
@endsection
<!-- <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script> -->
@section('my-script')
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.js"></script>
<script>
	$(document).ready(function() {
		$('#works-index').DataTable();
	});
    @error('company')
        $('#addModal').modal('show')
    @enderror
	@error('position')
        $('#addModal').modal('show')
    @enderror
	@error('works_place')
        $('#addModal').modal('show')
    @enderror
	@error('description')
        $('#addModal').modal('show')
    @enderror
</script>
@endsection
<script src="https://code.jquery.com/jquery-3.4.1.min.js" type="text/javascript"></script>